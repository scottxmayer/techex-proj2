## Project 2: Handwritten Digit Recognition with a Simple CNN 

pip install tensorflow-macos
pip install tensorflow-metal
